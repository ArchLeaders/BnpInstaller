# BnpInstaller

Installs BCML BNP's from CLI with BCML.

## Usage

`BnpInstaller install "path\to\mod.bnp"`
